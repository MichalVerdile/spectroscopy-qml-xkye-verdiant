# XGBoost raw-native results

All 25 runs completed on 20 November 2026. Each modality has seeds 41 through 45.

This directory contains experiment summaries, configuration snapshots, per-label metrics, training curves and logs. Source changes used for the runs are included in this branch.

Trained models, per-label UBJ checkpoints and binary prediction results remain on the persistent RunPod global volume mounted at /workspace. Their exact paths and sizes are listed in persistent_artifacts.json. Retain the volume.
