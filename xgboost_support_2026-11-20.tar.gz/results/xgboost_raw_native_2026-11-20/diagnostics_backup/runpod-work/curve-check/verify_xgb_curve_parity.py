"""Compare the optimized and reference scoring paths on actual saved fits."""
import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import cupy as cp
from xgboost import DMatrix


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("attempt", type=Path)
    parser.add_argument("cache", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    sys.path[:0] = [str(args.repo / "runpod"), str(args.repo / "src")]
    from curve_evaluation import evaluate_split, staged_labels
    from protocol import check_science, sha256, write_json

    print("REFERENCE_FILES_VERIFIED", len(check_science(args.repo)), flush=True)
    spec = importlib.util.spec_from_file_location(
        "baseline_xgb", args.repo / "benchmark/xgb/scripts/run_xgb_baseline.py"
    )
    trainer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(trainer)
    config = json.loads((args.attempt / "config.json").read_text())
    trainer.XGB_N_ESTIMATORS = config["n_estimators"]
    threads = 16
    model = trainer.build_xgboost_model(
        config["seed"], config["device"], threads, config["early_stopping_patience"]
    )
    model.estimators_ = []
    for index, label in enumerate(trainer.functional_groups):
        stem = f"label_{index:02d}"
        path = args.attempt / "label_models" / (stem + ".ubj")
        meta = json.loads(path.with_suffix(".json").read_text())
        assert meta["label_index"] == index and meta["label_name"] == label
        assert meta["model_sha256"] == sha256(path)
        estimator = trainer.clone(model.estimator)
        estimator.load_model(path)
        estimator.get_booster().load_config(json.dumps(meta["xgboost_config"]))
        assert int(estimator.best_iteration) == meta["best_iteration"]
        assert estimator.get_booster().num_boosted_rounds() == meta["fitted_rounds"]
        model.estimators_.append(estimator)
    print("CHECKPOINTS_VERIFIED", len(model.estimators_), flush=True)

    # Read only a prefix of the unchanged compressed matrix for the parity test.
    with ZipFile(args.cache) as archive, archive.open("X.npy") as x_file:
        version = np.lib.format.read_magic(x_file)
        readers = {
            (1, 0): np.lib.format.read_array_header_1_0,
            (2, 0): np.lib.format.read_array_header_2_0,
        }
        shape, fortran, dtype = readers[version](x_file)
        assert not fortran and dtype == np.float32 and shape[1] == config["input_dim"]
        prefix_rows = min(8192, shape[0])
        x_rows = np.frombuffer(x_file.read(prefix_rows * shape[1] * dtype.itemsize), dtype=dtype)
        x_rows = x_rows.reshape(prefix_rows, shape[1])
    with np.load(args.cache, allow_pickle=False) as cache:
        y = cache["y"]
    split_path = Path(config["split_path"])
    assert sha256(split_path) == config["split_sha256"]
    split = trainer.load_split_artifact(split_path, y, expected_seed=config["seed"])
    rounds = [est.get_booster().num_boosted_rounds() for est in model.estimators_]
    final_round = max(rounds)
    steps = sorted({min(s, final_round) for s in (20, 40, 200, 1000, 3000, 8000, final_round)})
    report = {"reference_commit": config["reference_commit"], "models": len(rounds),
              "stages": steps, "splits": {}, "device": cp.cuda.runtime.getDeviceProperties(0)["name"].decode()}
    for name in ("train", "val"):
        indices = split[name][split[name] < prefix_rows][:512]
        X = x_rows[indices]
        target = y[indices]
        time_ref = time.monotonic()
        reference = [trainer.predict_multioutput_at_step(model, X, stage) for stage in steps]
        reference_final = model.predict(X)
        time_ref = time.monotonic() - time_ref

        time_fast = time.monotonic()
        fast_final, (micro, macro) = evaluate_split(
            model, X, subset=name, target=target, steps=steps, threads=threads
        )
        time_fast = time.monotonic() - time_fast
        np.testing.assert_array_equal(fast_final, reference_final)
        for i, (predictions, f1_micro, f1_macro) in enumerate(zip(reference, micro, macro)):
            ref = trainer.compute_f1_metrics(target, predictions, prefix="ref")
            np.testing.assert_allclose((f1_micro, f1_macro),
                                       (ref["ref_f1_micro"], ref["ref_f1_macro"]),
                                       rtol=0, atol=2e-15, err_msg=f"{name} step {steps[i]}")
        matrix = DMatrix(cp.asarray(X), nthread=threads)
        for label, estimator in enumerate(model.estimators_):
            ends = [min(step, rounds[label]) for step in steps]
            by_end = dict(staged_labels(estimator, matrix, X, sorted(set(ends))))
            for i, end in enumerate(ends):
                np.testing.assert_array_equal(by_end[end], reference[i][:, label])
        del matrix
        report["splits"][name] = {"rows": len(X), "exact_label_parity": True,
                                  "old_seconds": time_ref, "new_seconds": time_fast}
        print(f"PARITY_OK {name} rows={len(X)} old={time_ref:.2f}s new={time_fast:.2f}s", flush=True)
    write_json(args.report, report)
    print("PARITY_PASSED", args.report, flush=True)


if __name__ == "__main__":
    main()
