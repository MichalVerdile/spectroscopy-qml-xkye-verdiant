#!/bin/bash
set -euo pipefail
export GIT_LFS_SKIP_SMUDGE=1
git clone https://github.com/MichalVerdile/spectroscopy-qml-xkye-verdiant.git /root/spectroscopy-qml
git -C /root/spectroscopy-qml switch ablation-further-study
test "$(git -C /root/spectroscopy-qml rev-parse HEAD)" = 01e270ee8ad79bb0978f96a709113df3d1f3b017
python -m venv --system-site-packages /root/runpod-work/venv
/root/runpod-work/venv/bin/python -m pip install numpy==2.4.2 pandas==3.0.0 pyarrow==23.0.0 iterative-stratification==0.1.9 scikit-learn==1.8.0 rdkit==2025.9.4 scipy==1.17.0 click==8.1.8 xgboost==3.1.3
if ! git lfs version; then
  apt-get update -qq
  apt-get install -y git-lfs
fi
/root/runpod-work/venv/bin/python -c 'import torch,xgboost; print(torch.__version__,torch.version.cuda,torch.cuda.is_available(),xgboost.__version__)'
echo BOOTSTRAP_READY
