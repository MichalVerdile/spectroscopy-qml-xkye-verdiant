from pathlib import Path
from datetime import datetime, timezone
import json,subprocess
root=Path('/workspace')
base=root/'experiments/xgboost_raw_native'
def read(path):
    try:return json.loads(path.read_text())
    except (OSError,ValueError):return {}
print('XGBOOST RAW-NATIVE - RunPod j4io8t82fkrccs')
print(datetime.now(timezone.utc).isoformat(timespec='seconds'))
print('Persistent storage: /workspace (Global Volume)')
print('Split files:',len(list((root/'shared_splits').glob('*.npz'))),'/25')
print('Local cache bytes:',sum(p.stat().st_size for p in Path('/root/runpod-work/cache').glob('*') if p.is_file()))
print('Persistent caches:',len(list((root/'data/cache').glob('*.npz'))))
status=read(base/'summaries/status.json')
print('Experiment status:',status.get('counts',{}))
print('Status updated:',status.get('updated','pending'))
for row in status.get('experiments',[]):
    if row.get('status')=='running':
        attempt=Path(row['attempt'])
        state=read(attempt/'status.json')
        print('ACTIVE:',row['modality'],'seed',row['seed'],'PID',state.get('training_pid'))
        print('Persisted label models:',len(list((attempt/'label_models').glob('*.ubj'))))
        print(subprocess.check_output(['ps','-p',str(state['training_pid']),'-o','pid,etime,%cpu,rss,state'],text=True).strip())
        try:print('\n'.join((attempt/'console.log').read_text().splitlines()[-5:]))
        except OSError:pass
print('Master log:')
print('\n'.join(Path('/root/runpod-work/master.log').read_text().splitlines()[-3:]))
print(subprocess.check_output(['nvidia-smi','--query-gpu=name,utilization.gpu,memory.used','--format=csv'],text=True).strip())
print(subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv'],text=True).strip())
